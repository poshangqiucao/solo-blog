title: MapReduce编程将文件中的城市代码替换为城市名称
date: '2019-09-19 19:59:56'
updated: '2019-09-19 20:24:39'
tags: [大数据-mapreduce]
permalink: /articles/2019/09/19/1568894396853.html
---
	我们的任务是将citylog.txt中的值对应编号关联匹配数据cityid.txt，将城市编码替换为城市名称输出。
下面是两个文件的大致内容：
citylog.txt
uid:131192622122401792|platform:Android|pid:5616|cityid:626	
uid:131192622122401792|platform:Android|pid:5616|cityid:626	
uid:131192622122401792|platform:Android|pid:5616|cityid:626	
uid:142873087346606080|platform:Android|pid:5057|cityid:86	
uid:142873087346606080|platform:Android|pid:5057|cityid:86	
uid:142873087346606080|platform:Android|pid:5057|cityid:86	
uid:142873087346606080|platform:Android|pid:5057|cityid:86	
uid:142873087346606080|platform:Android|pid:5057|cityid:86	
uid:142873087346606080|platform:Android|pid:5057|cityid:86	
...
...

cityid.txt
1701|桐城市|桐城市|安徽|中国|安庆市|华东地区|四线城市|31.05228|116.93861
1702|宿松县|宿松县|安徽|中国|安庆市|华东地区|四线城市|30.151213|116.1142
1703|枞阳县|枞阳县|安徽|中国|安庆市|华东地区|四线城市|30.69371|117.21059
1704|太湖县|太湖县|安徽|中国|安庆市|华东地区|四线城市|30.420059|116.26508
1705|怀宁县|怀宁县|安徽|中国|安庆市|华东地区|四线城市|30.409006|116.64709
1706|岳西县|岳西县|安徽|中国|安庆市|华东地区|四线城市|30.857161|116.35818
1707|望江县|望江县|安徽|中国|安庆市|华东地区|四线城市|30.123537|116.67433
1708|潜山县|潜山县|安徽|中国|安庆市|华东地区|四线城市|30.630346|116.5672
...
...

匹配替换的部分结果：
uid:252836603221901312|platform:Android|pid:5237|cityid:醴陵市	
uid:252836603221901312|platform:Android|pid:5237|cityid:醴陵市	
uid:252836603221901312|platform:Android|pid:5237|cityid:醴陵市	
uid:252836603221901312|platform:Android|pid:5237|cityid:醴陵市	
uid:252836603221901312|platform:Android|pid:5237|cityid:醴陵市	
uid:252836603221901312|platform:Android|pid:5237|cityid:醴陵市	
uid:252836603221901312|platform:Android|pid:5237|cityid:醴陵市	
uid:176831142119473152|platform:Android|pid:5115|cityid:番禺区	
uid:176831142119473152|platform:Android|pid:5115|cityid:番禺区	
uid:176831142119473152|platform:Android|pid:5115|cityid:番禺区	
uid:176831142119473152|platform:Android|pid:5115|cityid:番禺区	
uid:176831142119473152|platform:Android|pid:5115|cityid:番禺区	
uid:176831142119473152|platform:Android|pid:5115|cityid:番禺区	
uid:227915024260268032|platform:Android|pid:5057|cityid:南海区	
uid:227915024260268032|platform:Android|pid:5057|cityid:南海区	
uid:227915024260268032|platform:Android|pid:5057|cityid:南海区	
uid:227915024260268032|platform:Android|pid:5057|cityid:南海区	
uid:227915024260268032|platform:Android|pid:5057|cityid:南海区	
uid:227915024260268032|platform:Android|pid:5057|cityid:南海区	
uid:227915024260268032|platform:Android|pid:5057|cityid:南海区	
uid:227915024260268032|platform:Android|pid:5057|cityid:南海区	
uid:227915024260268032|platform:Android|pid:5057|cityid:南海区	
uid:227915024260268032|platform:Android|pid:5057|cityid:南海区	
uid:227915024260268032|platform:Android|pid:5057|cityid:南海区	
uid:227915024260268032|platform:Android|pid:5057|cityid:南海区	
uid:359048116|platform:Android|pid:5115|cityid:邳州市	
uid:359048116|platform:Android|pid:5115|cityid:邳州市	
uid:359048116|platform:Android|pid:5115|cityid:邳州市	
uid:359048116|platform:Android|pid:5115|cityid:邳州市	
uid:359048116|platform:Android|pid:5115|cityid:邳州市	
uid:359048116|platform:Android|pid:5115|cityid:邳州市	
uid:359048116|platform:Android|pid:5115|cityid:邳州市	
uid:192057585157931008|platform:Android|pid:5115|cityid:丰县	
uid:192057585157931008|platform:Android|pid:5115|cityid:丰县	
uid:192057585157931008|platform:Android|pid:5115|cityid:丰县	
uid:192057585157931008|platform:Android|pid:5115|cityid:丰县	
uid:192057585157931008|platform:Android|pid:5115|cityid:丰县

	
以下是实现代码：
 * 对cityid.txt进行map构建以城市代码为key,城市名称加a_前缀为值的键值对。

```
public static class CitylogMapper1 extends Mapper<LongWritable, Text, Text,Text>{
		public static final String LABEL = "a_";
		public void map(LongWritable key,Text value,Context context) throws IOException,InterruptedException {
			String line = value.toString();
			String[] item = line.split("[|]");
			context.write(new Text(item[0]),new Text(LABEL+item[1]));	
		}
	}
```

* 对citylog.txt进行map切出以城市代码为键，一行数据中除去城市代码并加上s_前缀为值。

```
public static class CitylogMapper2 extends Mapper<LongWritable, Text, Text,Text>{
		public static final String LABEL = "s_";
		public void map(LongWritable key,Text value,Context context) throws IOException,InterruptedException {		
			String line = value.toString();
			int i = line.lastIndexOf(":");
			context.write(new Text(line.substring(i+1)), new Text(LABEL+line.substring(0,i+1)));
		}
	}
```

* reducer操作使用一个cityname变量和一个ArrayList对象，分别记录城市名称和需要替换的文本。reduce函数的参数有一个键和一个可迭代的值对象。for循环获取可迭代的每一个值，判断值的前缀以a_开头则知道其携带的是城市名截取赋值给cityname变量。若是以s_开头则是需要替换的数据行，将其添加到ArrayList对象中，迭代完同一个key的所有值后，判断若cityname依然为null，则代表此城市代码没有相应的城市名称，不过这不大可能出现。只要cityname被赋值了，我们就找到了某了键的城市名称，就可以将ArrayList中的值一一取出赋值去掉前缀加上cityname，即可完成我们的任务。



```
public static class CityReducer extends Reducer<Text, Text, Text, Text>{
		String cityname = null;
		public void reduce(Text key,Iterable<Text> values,Context context) throws IOException,InterruptedException{
			ArrayList<String> list = new ArrayList<String>();
			for(Text val:values) {
				if(val.toString().startsWith(CitylogMapper1.LABEL)) {
					cityname = val.toString().substring(2);
				}
				else if (val.toString().startsWith(CitylogMapper2.LABEL)) {
					list.add(val.toString().substring(2));			
				}	
			}
			if(cityname!=null&&list.size()>0) {
				for(String str:list) {
					context.write(new Text(str+cityname), new Text(""));
				}
			}	
//			for(Text val:values) {
//			if(val.toString().startsWith(CitylogMapper1.LABEL)) {
//				citynameString=val.toString().substring(2);
//			}else {
//				context.write(new Text(val.toString().substring(2)+citynameString), new Text(""));
//			}	
//		}		
		}
	}
```

* 以下是主函数：

```
public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf,"Citymr");
		job.setJarByClass(CityMr.class);
		MultipleInputs.addInputPath(job, new Path(args[0]), TextInputFormat.class,CitylogMapper1.class);
		MultipleInputs.addInputPath(job, new Path(args[1]), TextInputFormat.class,CitylogMapper2.class);
//		job.setMapperClass(CitylogMapper.class);
		job.setReducerClass(CityReducer.class);
//		job.setMapOutputKeyClass(Text.class);
//		job.setMapOutputValueClass(Text.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);
//		FileInputFormat.setInputPaths(job,new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[2]));
		boolean b = job.waitForCompletion(true);	
		if(!b) {
			System.out.println("fail!");
		}
	}
}
```

	一点思考：
		cityname不能声明在reduce函数里，要不然结果替换的城市名称都是null。要作为类的成员变量来声明，为什么不能声明在reduce函数里呢？对于同一个key这个reduce函数调用一次，变量被声明一次，在下面的for循环中也会被赋值，应该也是可以正确替换的，但我的实践结果是替换的城市名全都是null。这有点想不明白。应该是我理解的Reducer原理有问题。
		为什么要在Map阶段给每一个值加前缀？这样在reduce阶段就可以根据前缀知道是哪个文件的值，可以做相应的处理，在我们这个任务中，通过加前缀我们知道同一个键的很多迭代值哪个值是需要替换输出的哪个值携带了这个键也就是城市代码对应的城市名称。就是区分这些值以作相应处理。
		以后这种替换任务都可以通过从两个文件中构建相同的key，一个键携带加前缀替换值，另一个携带加前缀被替换值。然后reduce阶段相同的key的值就被聚合在一起。我们就可以通过前缀区分两种值替换输出。





