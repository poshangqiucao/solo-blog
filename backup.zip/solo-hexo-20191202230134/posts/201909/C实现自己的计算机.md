title: C++实现自己的计算机
date: '2019-09-22 22:13:24'
updated: '2019-09-22 22:13:24'
tags: [C++]
permalink: /articles/2019/09/22/1569161604814.html
---
		这是《C++大学教程》第九版第八章的一道练习题，我们建立了一个称为Simpletron的计算机。它是一个很简单的计算机，只能运行它可以理解的机器语言编写的程序。我们把这种语言叫做SML语言，SML程序的每条指令是有符号的4位十进制数，前两位数字是操作码，指定要进行的操作，后两位数是操作数，也就是要包含要操作的数的内存位置。
		我们使用长度为100的一维数组作为Simpletron的内存。SML指令将被装载到这个数组中供后续运行。变量accumulator代表累加寄存器，变量instructionCounter记录记录当前执行指令的内存位置，变量operationCode表示当前指令指定的操作类型，operand代表当前指令所操作的内存位置。执行SML程序总是先从内存的00位置读取指令，并取出其操作码，按照操作码执行相应的操作类型，例如从键盘获得用户输入存入内存相应位置，打印内存某位置的值，取出内存某位置值与累加器中的值进行加减乘除操作，或者将程序跳转到某位置。
		这个示例很简单，但是在一定程度上演示了机器代码的执行过程。
		我并没有实现内存转储。
```
#include <iostream>
using namespace std;

int main(int argc, char** argv) {
	
	const int read =10;
	const int write = 11;
	const int load = 20;
	const int store = 21;
	const int add = 30;
	const int subtract = 31;
	const int divide = 32;
	const int multiply = 33;
	const int branch = 40;
	const int branchneg = 41;
	const int branchzero = 42;
	const int halt = 43;
	 
	int memory[100];
	int accumulator = 0;
	int instructionCounter = 0;
	int operationCode = 0;
	int operand = 0;
	int instructionRegister = 0;
	
	
	cout << "***Welcome to Simpletron!***" << endl;
	cout << "***Please enter your program one instruction***" << endl;
	cout << "***(or data word) at a time.I will type the***" << endl;
	cout << "***location number and a question mark ?***" << endl;
	cout << "***You then type the word for that location***" << endl;
	cout << "***Type the sentinel -99999 to stop entering***" << endl;
	cout << "***You program.****" <<endl;
	
	int i = 0;
	int temp=0;
	while(1){
		if(i>=100){
			break;
		}
		cout << "?" << " " ;
		cin >> temp;
		if(temp<-9999||temp>+9999){
			if(temp==-99999){
				cout << "***Program loading completed***" <<endl;
				cout << "***Program execution begins ***" <<endl;
				break;
			} 
			cout << "Wrong Number!" << endl;
			continue;
		}
		memory[i] = temp;	
		++i;
		
	}
	while(1){
		instructionRegister = memory[instructionCounter];
		operationCode = instructionRegister/100;
		operand = instructionRegister%100;
	
		switch(operationCode){
			case read:
				cout << "?" << " " ;
				cin >> memory[operand];
				++instructionCounter;
				break;
			case write:
				cout << memory[operand] << endl;
				++instructionCounter;				
				break;
			case load:
				accumulator = memory[operand];
				++instructionCounter;
				break;
			case store:
				memory[operand] = accumulator;
				++instructionCounter;
				break;
			case add:
				accumulator+=memory[operand];
				++instructionCounter;
				break;
			case subtract:
				accumulator-=memory[operand];
				++instructionCounter;
				break;
			case divide:
				if(memory[operand]==0){
					cout << "***Attempt to divide by zero ***" <<endl;
					cout << "***Simpletron execution abnormally terminated ***" << endl;
					return 0;
				}
				accumulator/=memory[operand];
				++instructionCounter;
				break;
			case multiply:
				accumulator*=memory[operand];
				++instructionCounter;
				break;
			case branch:
				instructionCounter = operand;
				break;
			case branchneg:
				if(accumulator<0){
					instructionCounter = operand;
				}
				break;
			case branchzero:
				if(accumulator==0){
					instructionCounter = operand;
				}
				break;
			case halt:
				cout << "*** Simpletron execution terminated! ***" << endl;
				return 0;
				break;	
		}	
	}
		
	return 0; 
}

```
下面是一个SML程序实现比较用户输入的两个数输出较大的数。

```
***Welcome to Simpletron!***
***Please enter your program one instruction***
***(or data word) at a time.I will type the***
***location number and a question mark ?***
***You then type the word for that location***
***Type the sentinel -99999 to stop entering***
***You program.****
? 1009
? 1010
? 2009
? 3110
? 4107
? 1109
? 4300
? 1110
? 4300
? 0000
? 0000
? -99999
***Program loading completed***
***Program execution begins ***
? 32
? 33
33
*** Simpletron execution terminated! ***
```
